#include <iostream>
using namespace std;
//
struct SV{
	string name;
	int day;
	int month;
	int year;
	double math;
	double physic;
	double language;
	SV *next;
};
SV *L;
void Inp(SV *&L){
	SV *P,*C;
	int n;
	int count=1;
	cout << "Nhap so luong sinh vien: ";
	cin >> n;
	while(count<=n){
		P = new SV;
		cout << "Thong tin sinh vien:\n";
		cout << "Nhap ten: ";
		cin >> P->name;
		cout << "Nhap ngay sinh: ";
		cin >> P->day;
		cout << "Nhap thang sinh: ";
		cin >> P->month;
		cout << "Nhap nam sinh: ";
		cin >> P->year;
		cout << "Nhap diem toan: ";
		cin >> P->math;
		cout << "Nhap diem ly: ";
		cin >> P->physic;
		cout << "Nhap diem van: ";
		cin >> P->language;
		P->next=NULL;
		if(L==NULL){
			L=P;
			C=P;
		}else{
			C->next=P;
			C=P;
		}	
		count++;
	}
}
//
void Outp(SV *L){
	SV *P;
	int count=0;
	P=L;
	while(P!=NULL){
		count++;
		cout << count << endl;
		cout << "Name: " << P->name << "\nDOB: " << P->day << "/" << P->month << "/" << P->year << "\nMath: " << P->math << "\nPhysic: " << P->physic << "\nLanguage: " << P->language << endl;
		P=P->next;
	}
}
//
void Add(SV *&L){
	int dem = 0;
	SV *P,*Q;
	P=new SV; //cap phat bo nho con tro p
	 cout << "Thong tin sinh vien:\n";
		cout << "Nhap ten: ";
		cin >> P->name;
		cout << "Nhap ngay sinh: ";
		cin >> P->day;
		cout << "Nhap thang sinh: ";
		cin >> P->month;
		cout << "Nhap nam sinh: ";
		cin >> P->year;
		cout << "Nhap diem toan: ";
		cin >> P->math;
		cout << "Nhap diem ly: ";
		cin >> P->physic;
		cout << "Nhap diem van: ";
		cin >> P->language;//gan gia tri x vao truong so cua con tro p
	Q=L;
	while(Q->next!=NULL){
		Q = Q->next;
	}
		P->next=Q->next;
		Q->next=P;
}
//
int count_student_in_year(SV *&L,int year){
	SV *Q;
	int count = 0;
	Q = L;
	while(Q != NULL){
		if(Q->year == year){
			count++;
		}
		Q = Q->next;
	}
	return count;
}
//
bool has_student(SV *&L,string name){
	SV *Q;
	Q = L;
	while(Q!=NULL){
		if(Q->name == name){
			return true;
		}
		Q = Q->next;
	}
	return false;
}
//
void delete_student(SV *&L,string name){
	SV *Q;
	SV *P;
	if(L == NULL){
		return;
	}
	if(L->name == name){
		Q = L;
		L = L->next;
		delete(Q);
		return;
	}
	P = L;
	while(P->next != NULL){
		if(P->next->name == name){
			Q = L->next;
			L->next = Q->next;
			delete(Q);
			return;
		}
	}
}
//
void print_students_with_math_less_than_5() {
	SV *Q;
    Q = L;
        while (Q != NULL) {
            if (Q->math < 5){
			 cout << Q->name;
		}
		Q = Q->next;
}
}
int main(){
	L=NULL;
	Inp(L);
	cout << "\nDanh sach:\n";
	Outp(L);
//	cout << "SV sinh nam 2004: " << count_student_in_year(L,2004) << endl;
//	if(has_student(L,"duong")) cout << "ton tai";
//	else cout << "khong ton tai";
//	delete_student(L,"duong");
//	
////	Add(L);
//	cout << "\nDanh sach sau xoa:\n";
//	Outp(L);
print_students_with_math_less_than_5();
	delete(L);
	return 0;
}
