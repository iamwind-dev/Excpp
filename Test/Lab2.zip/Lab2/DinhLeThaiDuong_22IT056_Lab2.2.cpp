#include<iostream>
using namespace std;

// Structure of a node in the linked list
struct node
{
    int num;
    int coeff;
    struct node* next;
};




// Function to print the polynomial
void print_poly(struct node* poly)
{
    if (poly == NULL)
    {
        cout << "0\n";
        return;
    }

    while (poly != NULL)
    {
        if (poly->num == 0)
        {
            // Skip this term if its exponent is 0
            poly = poly->next;
            continue;
        }

        if (poly->num == 1)
        {
            cout << poly->coeff << "x";
        }
        else
        {
            cout << poly->coeff << "x^" << poly->num;
        }

        poly = poly->next;
        if (poly != NULL)
        {
            // Print + sign if there are more terms
            cout << " + ";
        }
    }
    cout << endl;
}


// Function to input a polynomial and store it in a linked list
struct node* input_poly()
{
    struct node* poly = NULL;
    struct node* last_term = NULL;
    int n;

    cout << "Enter the number of terms in the polynomial: ";
    cin >> n;

    for (int i = 1; i <= n; i++)
    {
        int num, coeff;
        cout << "Enter the coefficient and exponent of term " << i << ": ";
        cin >> coeff >> num;

        struct node* new_term = new node;
        new_term->num = num;
        new_term->coeff = coeff;
        new_term->next = NULL;

        if (poly == NULL)
        {
            poly = new_term;
            last_term = new_term;
        }
        else
        {
            last_term->next = new_term;
            last_term = new_term;
        }
    }

    return poly;
}
struct node* add_poly(struct node* poly1, struct node* poly2)
{
    struct node* result = NULL;
    struct node* last_term = NULL;

    while (poly1 != NULL && poly2 != NULL)
    {
        struct node* new_term = new node;

        if (poly1->num == poly2->num)
        {
            // If the exponents match, add the coefficients
            new_term->coeff = poly1->coeff + poly2->coeff;
            new_term->num = poly1->num;

            poly1 = poly1->next;
            poly2 = poly2->next;
        }
        else if (poly1->num > poly2->num)
        {
            // If the exponent of the first polynomial is greater, append the term to the result
            new_term->coeff = poly1->coeff;
            new_term->num = poly1->num;

            poly1 = poly1->next;
        }
        else
        {
            // If the exponent of the second polynomial is greater, append the term to the result
            new_term->coeff = poly2->coeff;
            new_term->num = poly2->num;

            poly2 = poly2->next;
        }

        new_term->next = NULL;
        if (result == NULL)
        {
            result = new_term;
            last_term = new_term;
        }
        else
        {
            last_term->next = new_term;
            last_term = new_term;
        }
    }

    // Append any remaining terms from the first polynomial
    while (poly1 != NULL)
    {
        struct node* new_term = new node;
        new_term->coeff = poly1->coeff;
        new_term->num = poly1->num;
        new_term->next = NULL;

        last_term->next = new_term;
        last_term = new_term;
        poly1 = poly1->next;
    }

    // Append any remaining terms from the second polynomial
    while (poly2 != NULL)
    {
        struct node* new_term = new node;
        new_term->coeff = poly2->coeff;
        new_term->num = poly2->num;
        new_term->next = NULL;

        last_term->next = new_term;
        last_term = new_term;
        poly2 = poly2->next;
    }

    return result;
}

// Function to subtract two polynomials
struct node* subtract_poly(struct node* poly1, struct node* poly2)
{
	struct node* result = NULL;
	// Traverse both the polynomials
	while(poly1 != NULL && poly2 != NULL)
	{
	    if(poly1->num == poly2->num)
	    {
	        // Subtract the coefficients of the terms with the same power
	        int coef = poly1->coeff - poly2->coeff;
	        if(coef != 0)
	        {
	            // Create a new node for the result polynomial
	            struct node* newnode = new node;
	            newnode->num = poly1->num;
	            newnode->coeff = coef;
	            newnode->next = result;
	            result = newnode;
	        }
	        // Move both the pointers to the next term
	        poly1 = poly1->next;
	        poly2 = poly2->next;
	    }
	    else if(poly1->num > poly2->num)
	    {
	        // Copy the term with higher power to the result polynomial
	        struct node* newnode = new node;
	        newnode->num = poly1->num;
	        newnode->coeff = poly1->coeff;
	        newnode->next = result;
	        result = newnode;
	        // Move the pointer of the polynomial with higher power to the next term
	        poly1 = poly1->next;
	    }
	    else
	    {
	        // Copy the term with higher power to the result polynomial with the coefficient negated
	        struct node* newnode = new node;
	        newnode->num = poly2->num;
	        newnode->coeff = -poly2->coeff;
	        newnode->next = result;
	        result = newnode;
	        // Move the pointer of the polynomial with higher power to the next term
	        poly2 = poly2->next;
	    }
	}
	// Copy any remaining terms from the polynomials to the result polynomial
	while(poly1 != NULL)
	{
	    struct node* newnode = new node;
	    newnode->num = poly1->num;
	    newnode->coeff = poly1->coeff;
	    newnode->next = result;
	    result = newnode;
	    poly1 = poly1->next;
	}
	while(poly2 != NULL)
	{
	    struct node* newnode = new node;
	    newnode->num = poly2->num;
	    newnode->coeff = -poly2->coeff;
	    newnode->next = result;
	    result = newnode;
	    poly2 = poly2->next;
	}
	
	// Reverse the result polynomial
	struct node* prev = NULL;
	struct node* current = result;
	struct node* next = NULL;
	while(current != NULL)
	{
		next = current->next;
		current->next = prev;
		prev = current;
		current = next;
	}
	result = prev;
	return result;
}
int main()
{
	struct node* poly1 = NULL;
	struct node* poly2 = NULL;
	// Input first polynomial
	cout << "Enter the first polynomial:" << endl;
	poly1 = input_poly();
	cout << "The first polynomial is:" << endl;
	print_poly(poly1);
	
	// Input second polynomial
	cout << "Enter the second polynomial:" << endl;
	poly2 = input_poly();
	cout << "The second polynomial is:" << endl;
	print_poly(poly2);
	
	 //Add the two polynomials
	struct node* sum = add_poly(poly1, poly2);
	cout << "The sum of the two polynomials is:" << endl;
	print_poly(sum);
	
	// Subtract the two polynomials
	struct node* diff = subtract_poly(poly1, poly2);
	cout << "The difference of the two polynomials is:" << endl;
	print_poly(diff);
	delete(poly1);
	delete(poly2);
	return 0;
}
	

